---
name: Groww Review Pulse
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daea'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eefe'
  surface-container-high: '#e2e8f8'
  surface-container-highest: '#dce2f3'
  on-surface: '#151c27'
  on-surface-variant: '#3c4a43'
  inverse-surface: '#2a313d'
  inverse-on-surface: '#ebf1ff'
  outline: '#6c7a73'
  outline-variant: '#bbcac1'
  surface-tint: '#006c4f'
  primary: '#006c4f'
  on-primary: '#ffffff'
  primary-container: '#00b386'
  on-primary-container: '#003d2c'
  inverse-primary: '#50ddad'
  secondary: '#575e70'
  on-secondary: '#ffffff'
  secondary-container: '#d9dff5'
  on-secondary-container: '#5c6274'
  tertiary: '#904d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#ea841b'
  on-tertiary-container: '#542a00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#71fac8'
  primary-fixed-dim: '#50ddad'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#00513b'
  secondary-fixed: '#dce2f7'
  secondary-fixed-dim: '#c0c6db'
  on-secondary-fixed: '#141b2b'
  on-secondary-fixed-variant: '#404758'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#f9f9ff'
  on-background: '#151c27'
  surface-variant: '#dce2f3'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
  data-lg:
    fontFamily: JetBrains Mono
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  data-md:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
  data-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style
The design system establishes a high-performance, internal analytics environment balancing institutional rigor with contemporary fintech energy. Created for product operators, risk leads, and customer experience analysts monitoring customer sentiment and transaction feedback, the aesthetic is precise, data-dense, and quietly authoritative.

The visual direction merges **Modern Corporate Utility** with an **Editorial Analytics** mindset. Rather than flashy consumer gamification, the interface prioritizes extreme legibility, instantaneous scanning, and semantic integrity across complex tabular and timeseries data. Visual calm is achieved through structured white surfaces, hairline slate borders, and purposeful chromatic signals where Groww's signature emerald green signifies momentum, warm amber flags latency or watchlists, and restrained crimson isolates regressions.

## Colors
The palette balances neutral paper-like surfaces with disciplined transactional indicators:

- **Primary Canvas & Surfaces**: Base backdrop uses `#F8F9FA`, elevated workcards and data sheets use `#FFFFFF`, and muted structural sections (toolbars, filters) use `#F1F3F5`.
- **Text & Hierarchy**: Primary labels and values employ deep charcoal `#111827`, secondary metadata `#374151`, and captions `#6B7280`. Pure black is avoided to prevent visual fatigue during prolonged analytical sessions.
- **Brand & Positive Momentum**: Groww signature emerald spectrum (`#00D09C` for high-visibility badges, `#00B386` for active interactions and primary actions, `#059669` for text-level positive metrics on light backgrounds).
- **Attention & Negative Signals**: Restrained coral `#DC2626` backed by light wash `#FEE2E2` for downward trends or critical issues; warm amber `#D97706` backed by `#FEF3C7` for warnings and neutral shifts.
- **Dividers & Structural Borders**: Crisp `#E5E7EB` for internal cell dividers, `#E2E8F0` for card boundaries and module outlines.

## Typography
Typography is split into three deliberate roles:

1. **Plus Jakarta Sans** provides a contemporary, modern grotesque presence for module headers, section banners, and primary dashboard metrics.
2. **Inter** serves as the utilitarian workhorse for narrative user reviews, sentiment categorization, filters, and standard UI navigation. All numerals in Inter should enforce OpenType `tnum` (tabular lining) to maintain column alignment.
3. **JetBrains Mono** is reserved for high-precision data fields: volume counters, NPS deltas, timestamp metadata, issue IDs, and real-time processing statistics.

## Layout & Spacing
The analytics workspace operates on an information-dense, 12-column fluid grid designed for high resolution displays (1440px+) while retaining fluid responsiveness down to tablets and operations consoles.

- **Grid & Margins**: Desktop uses a persistent 240px or 64px collapsed utility sidebar, followed by a primary content canvas framed with `margin-lg` (2rem) and `gutter-lg` (1.5rem). For compact laptop viewports (1024px–1280px), gutters pull in to `gutter` (1rem).
- **Vertical Rhythm**: Micro-level data pairs (e.g., metric label to numerical value) use `space-xs` (4px). Related interactive elements within filter rows utilize `space-sm` (8px). Standard table cell padding is clamped to `0.625rem` vertical and `0.75rem` horizontal to allow up to 18 rows in standard viewport heights without scrolling.

## Elevation & Depth
Depth is created through low-contrast outlines and micro-tonal shifts rather than heavy drop shadows:

- **Level 0 (Canvas Base)**: `#F8F9FA`. Background ground plane.
- **Level 1 (Card & Module Layer)**: `#FFFFFF` bounded by a 1px solid `#E2E8F0` border. No drop shadow in resting state.
- **Level 2 (Hover & Active Context)**: `#FFFFFF` surface with a delicate diffuse boundary shadow: `0 2px 4px -1px rgba(17, 24, 39, 0.04), 0 4px 6px -1px rgba(17, 24, 39, 0.02)` and border shifted to `#CBD5E1`.
- **Level 3 (Overlays, Flyouts & Drawers)**: `#FFFFFF` container with `0 10px 15px -3px rgba(17, 24, 39, 0.08), 0 4px 6px -2px rgba(17, 24, 39, 0.03)` with a structural border `#E5E7EB`.
- **Inset Tonal Wells**: Filter toolbars, search headers, and nested data breakdowns use `#F1F3F5` with an interior boundary border `#E5E7EB` to visually anchor sub-workflows.

## Shapes
A restrained roundedness (`0.25rem` / 4px base) anchors the institutional fintech character. 
- Form inputs, segmented controllers, and standard buttons employ `0.25rem` (4px) radii.
- Analytical cards, charts, and table viewports scale to `0.375rem` (6px) to maintain a crisp, engineered boundary without looking harsh or stark.
- Status badges and tag indicators leverage a semi-pill (`rounded-full` or `9999px`) strictly to differentiate actionable controls from passive categorization indicators.

## Components

### Buttons
- **Primary**: Background `#00B386`, text `#FFFFFF`, hover `#059669`, active `#047857`. Typography: Inter medium 13px, padding: 6px 14px. Border-radius: 4px.
- **Secondary / Ghost**: Background `#FFFFFF`, border 1px solid `#E5E7EB`, text `#1F2937`, hover background `#F8F9FA`, hover border `#CBD5E1`.
- **Destructive**: Background `#FFFFFF`, border 1px solid `#FEE2E2`, text `#DC2626`, hover background `#FEF2F2`.

### Cards & Data Containers
- White `#FFFFFF` canvas, 1px solid `#E2E8F0` border.
- Header row contains clean label in Plus Jakarta Sans (600, 14px), optional status chip, and right-aligned timeframe toggle. Separated from body by a hairline `#F1F3F5` border.

### Chips & Sentiment Badges
- **Positive Sentiment / Upward**: Light tint `#ECFDF5`, text `#059669`, border 1px solid `#A7F3D0`.
- **Neutral / Watchlist**: Light tint `#FEF3C7`, text `#D97706`, border 1px solid `#FDE68A`.
- **Negative / Alert**: Light tint `#FEF2F2`, text `#DC2626`, border 1px solid `#FECACA`.
- Format: Inline-flex, horizontal padding 8px, vertical padding 2px, radius 9999px. Typography: Inter 11px semi-bold.

### Input Fields & Filter Controls
- Height: 32px for compact analytics density.
- Background: `#FFFFFF`, border: 1px solid `#E5E7EB`, font: Inter 13px regular.
- Focus state: Border color `#00B386` paired with a 2px outer ring in `rgba(0, 179, 134, 0.15)`. No default browser outlines.

### Data Tables & Review Stream Lists
- Header: `#F8F9FA` background, uppercase 11px Inter medium labels, letter spacing 0.05em, color `#6B7280`.
- Rows: `#FFFFFF` resting, hover `#F8F9FA`, selected state `#F0FDF9`.
- Numeric values: Right-aligned using JetBrains Mono with tabular numbers.
- Hairline divider `#E5E7EB` between rows. Zero vertical table borders.